// src/pages/Home/Home.jsx
import HeroBanner from '../../organisms/HeroBanner/HeroBanner';
import BrandStrip from '../../organisms/BrandStrip/BrandStrip';
import ProductGrid from '../../organisms/ProductGrid/ProductGrid';
import DressStyleCategories from '../../organisms/DressStyleCategories/DressStyleCategories';
import CustomerTestimonials from '../../organisms/CustomerTestimonials/CustomerTestimonials';
import { products } from '../../../Data/Product';

const Home = () => {
  const newArrivals = products.filter(product => product.category === 'new');
  const topSelling = products.filter(product => product.category === 'top');

  return (
    <>
      <HeroBanner />
      <BrandStrip />
      <ProductGrid title="NEW ARRIVALS" products={newArrivals} showViewMore />
      <hr />
      <ProductGrid title="TOP SELLING" products={topSelling} showViewMore />
      <hr />
      <DressStyleCategories />
      <CustomerTestimonials />
     
    </>
  );
};

export default Home;
