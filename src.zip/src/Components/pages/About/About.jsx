import styles from './About.module.scss';
import { Box, Typography, Avatar } from '@mui/material';

const About = () => {
  return (
    <Box className={styles.about}>
      <Typography variant="h3" className={styles.heading}>About Us</Typography>
      <Typography variant="body1" className={styles.intro}>
        We build modular, motorsport-inspired interfaces that blend precision, speed, and expressive design.
        Our mission is to craft scalable frontend systems that feel as fast as they look.
      </Typography>

      <Box className={styles.team}>
        <Typography variant="h5">Meet the Crew</Typography>
        <Box className={styles.members}>
          <Box className={styles.member}>
            <Avatar src="/images/kushal.jpg" alt="Kushal" />
            <Typography variant="subtitle1">Kushal</Typography>
            <Typography variant="caption">Frontend Architect</Typography>
          </Box>
          {/* Add more team members here */}
        </Box>
      </Box>

      <Box className={styles.values}>
        <Typography variant="h5">Our Values</Typography>
        <ul>
          <li>⚙️ Modularity over mess</li>
          <li>🚀 Speed with precision</li>
          <li>🎯 Pixel-perfect execution</li>
          <li>🔍 Debugging with intent</li>
        </ul>
      </Box>
    </Box>
  );
};

export default About;
